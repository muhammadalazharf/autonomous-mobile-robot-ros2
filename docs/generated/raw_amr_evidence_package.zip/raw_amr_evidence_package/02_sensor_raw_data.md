# 02 — Data Raw Sensor

Sensor dan keterkaitannya dengan pipeline. Parameter LiDAR (range, angle_increment) terverifikasi dari data scan eksperimen.

| sensor | prinsip | output | topic | frame_id | rate | resolusi | param | node_pembaca | dipakai_untuk | bukti | status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RPLIDAR C1 | ToF laser scan 360 planar | sensor_msgs/LaserScan | /scan | laser_frame | ~10 Hz (scan_time 0.1001 s) | angle_increment 0.008714 rad (~720 titik) | baud 460800, scan_mode Standard, range 0.15-16.0 m | rtabmap, nav2 costmap, slam_toolbox, failover | mapping, costmap, scan-matching, e-stop | src/amr_bringup/launch/sensors_launch.py + data_lidar_1meter.txt (LaserScan mentah 1 m) | Terverifikasi dari file |
| RealSense D455 RGB | Kamera warna | sensor_msgs/Image | /camera/camera/color/image_raw | camera_color_optical_frame | 30 fps | 848x480 | gain 64, exposure 156, auto_exposure | rgbd_sync | mapping, loop closure (BoW) | src/amr_bringup/launch/sensors_launch.py | Terverifikasi dari file |
| RealSense D455 Depth | Stereo depth | sensor_msgs/Image | /camera/camera/aligned_depth_to_color/image_raw | camera_depth_optical_frame | 30 fps | 848x480 | align_depth=true, temporal+spatial filter on, decimation off | rgbd_sync, vr_inference | mapping 3D, depth regression | src/amr_bringup/launch/sensors_launch.py | Terverifikasi dari file |
| RealSense D455 IMU | MEMS IMU (BMI055) | sensor_msgs/Imu (accel+gyro) | /camera/camera/accel/sample, /gyro/sample -> /imu/data | camera_gyro_optical_frame | accel ~100 Hz, gyro ~200 Hz | - | unite_imu_method=2, sync slop 50 ms | imu_merger, rgbd_odometry | VIO, gravity constraint | src/amr_controller/scripts/imu_merger_node.py | Terverifikasi dari file |
| Encoder PG45 | Rotary increment | std_msgs/Int32 (delta ticks) | /encoder | - | via bridge read loop | PPR efektif 3858; dist_per_tick 0.1262 mm | auto-detect cumulative/delta | odometry_publisher | odometry | src/amr_controller/scripts/odometry_publisher.py | Terverifikasi dari file |
