# 05 — Model Robot (URDF/Xacro)

Parameter geometri & struktur link/joint, terverifikasi dari URDF.

| parameter | nilai | satuan | bukti | status |
|---|---|---|---|---|
| wheelbase | 0.500 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| track_width | 0.400 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| wheel_radius | 0.0775 | m (D=155mm) | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| wheel_width | 0.060 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| chassis (LxWxH) | 0.600 x 0.350 x 0.150 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| chassis_mass | 6.0 | kg | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| steering_range | ±45 | deg | src/amr_controller/src/stm32_bridge.cpp | Terverifikasi dari file |
| min_turning_radius | 0.90 (Nav2); 0.5-0.9 (rancangan) | m | src/amr_slam/config/nav2_params.yaml | Terverifikasi dari file |
| lidar_height (z) | 0.250 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| camera_x | 0.350 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| camera_height (z) | 0.200 | m | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |


## Link
- base_footprint
- base_link
- chassis
- rear_left_wheel
- rear_right_wheel
- front_left_steering_link
- front_left_wheel
- front_right_steering_link
- front_right_wheel
- laser_frame
- camera_link
- color_optical_frame
- depth_optical_frame

## Joint
- base_footprint_joint (fixed)
- chassis_joint (fixed)
- rear_*_wheel_joint (continuous Y)
- front_*_steering_joint (revolute Z)
- front_*_wheel_joint (continuous Y)
- laser_joint (fixed)
- camera_joint (fixed)
- color/depth_optical_joint (fixed, REP-103)
