# 03 — Inventaris Package ROS 2

Tujuh package ROS 2 dan tanggung jawabnya.

| package | fungsi | node_file | launch | config | publish | subscribe | service_action | relasi | bukti | status |
|---|---|---|---|---|---|---|---|---|---|---|
| amr_description | Model URDF/Xacro + TF | robot_state_publisher | view_robot.launch.py | urdf/*.xacro | /robot_description, /tf_static | - | - | dipakai amr_bringup | src/amr_description/urdf/amr_description.urdf.xacro | Terverifikasi dari file |
| amr_controller | Bridge HW + odometry + IMU merge | stm32_bridge.cpp, odometry_publisher.py, imu_merger_node.py | (via amr_launch.py) | - | /encoder, /odom, /imu/data, /tf | /cmd_vel, /joy | - | input ke RTAB-Map/Nav2 | src/amr_controller/src/stm32_bridge.cpp | Terverifikasi dari file |
| amr_bringup | Orkestrasi launch + sensor + joy | joy_node, teleop | amr_full/sensors/amr_launch.py | joy_params.yaml | /scan, /camera/*, /joy | - | - | master launch semua | src/amr_bringup/launch/amr_full.launch.py | Terverifikasi dari file |
| amr_3d_mapping | SLAM 3D RTAB-Map + VIO | rtabmap, rgbd_odometry, rgbd_sync | rtabmap_mapping/localization/vio_only.launch.py | rtabmap_mapping.yaml, rtabmap_localization.yaml | /map, /cloud_map, /tf(map->odom) | /rgbd_image, /scan, /imu/data | rtabmap services | peta untuk Nav2 | src/amr_3d_mapping/config/rtabmap_mapping.yaml | Terverifikasi dari file |
| amr_slam | SLAM Toolbox 2D + Nav2 config | slam_toolbox, nav2 lifecycle nodes | nav2.launch.py, slam_mapping/localization.launch.py | nav2_params.yaml, slam_mapping.yaml | /cmd_vel, /plan, /global_costmap, /local_costmap | /scan, /odom, /map | /navigate_to_pose (action) | konsumen peta RTAB-Map | src/amr_slam/config/nav2_params.yaml | Terverifikasi dari file |
| amr_visual_regression | Fallback depth-regression + line segments | vr_inference, data_collector, lidar_line_segments, feature_extractor | vr_inference/line_segments/collect_dataset.launch.py | model .pkl (offline) | /cmd_vel_visual, /amr/line_segments | /camera/depth/*, /scan | - | sumber VISUAL_FALLBACK failover | src/amr_visual_regression/amr_visual_regression/vr_inference_node.py | Terverifikasi dari file |
| amr_failover | Arbiter cmd_vel (state machine) | failover_controller.py | failover.launch.py | param node | /cmd_vel, /failover_status, /failover_marker | /cmd_vel_nav, /cmd_vel_visual, /cmd_vel_joy, /scan, /map, /joy | - | arbiter semua sumber gerak | src/amr_failover/amr_failover/failover_controller.py | Terverifikasi dari file |
